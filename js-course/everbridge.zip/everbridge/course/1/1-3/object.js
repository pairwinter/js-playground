$(function(){
	var jc = js_course;

});